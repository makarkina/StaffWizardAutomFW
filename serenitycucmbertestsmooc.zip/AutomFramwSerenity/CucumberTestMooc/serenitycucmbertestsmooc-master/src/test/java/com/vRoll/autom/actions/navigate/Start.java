package com.vRoll.autom.actions.navigate;

import com.vRoll.autom.pages.LoginPage;
import net.serenitybdd.core.steps.Instrumented;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actions.OpenPage;

public class Start implements Performable {
    private LoginPage loginPage;


    public <T extends Actor> void performAs(T actor){
        actor.attemptsTo(Open.browserOn(loginPage));
        //actor.wasAbleTo(OpenPage.loginPage);
    }

    public static Performable openingApps() {
        return Instrumented.instanceOf(Start.class).newInstance();
    }

}
