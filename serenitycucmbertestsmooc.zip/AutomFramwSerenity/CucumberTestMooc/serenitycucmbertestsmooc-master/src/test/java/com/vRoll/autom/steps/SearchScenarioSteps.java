package com.vRoll.autom.steps;

import com.vRoll.autom.pages.CompanyPage;
import com.vRoll.autom.pages.CompanyScreen;
import com.vRoll.autom.pages.LoginPage;
import com.vRoll.autom.pages.MainPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.targets.Target;
import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.By;


public class SearchScenarioSteps {
    LoginPage loginPage;
    MainPage mainPage;
    CompanyPage companyPage;
    CompanyScreen companyScreen;

    Actor user;

    @Before
    public void set_the_stage(){
        OnStage.setTheStage(new OnlineCast());
        Actor user;

    }

    @Given("^user opens the application$")
    public void givenUserOpensTheSite() {
        loginPage.open();
    }

    @Given("^user login using (.*) and (.*)$")
    public void givenUserOpensTheSite(String userName, String password) {
        loginPage.typeUserName(userName);
        loginPage.typePassword(password);
        loginPage.clickSubmit();
    }

    @When("user selects Company mode on main page")
    public void userSelectsCompanyMode(){
        mainPage.selectCompaniesMode();
    }

    public static final Target SELECTED_COMPANY = Target.the("New company")
            .located(By.xpath("//i[@class='fa fa-plus fs20']"));

    @When("(.*) adds a new company")
    public void userAddsNewCompany(String actorName){
        //companyPage.addNewCompany();
        companyPage.waitForElement();
        companyPage.selectCompany();
        //OnStage.theActorCalled(actorName).attemptsTo(AddNewCompany.usingPlus());
        //OnStage.theActorCalled(actorName).attemptsTo(DoubleClick.);
        /*Actor ourActor = Actor.named(actorName);
        ourActor.attemptsTo(Click.on(SELECTED_COMPANY));*/

    }

    @Then("user verifies (.*)")
    public void thenShouldBeDisplayed(String expectedName){
        Assert.assertEquals(companyScreen.getName(), expectedName);
    }

}
