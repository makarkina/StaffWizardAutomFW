package com.vRoll.autom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

public class MainPage extends PageObject{
        @FindBy(xpath="//a[@data-href='forms/company/list']")
        WebElementFacade companiesMode;

        public void selectCompaniesMode(){
            companiesMode.click();
            System.out.println("companiesMode");
        }
}
