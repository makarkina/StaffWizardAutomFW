package com.vRoll.autom.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.support.FindBy;

public class CompanyPage extends PageObject {

    @FindBy(xpath="//i[@class='fa fa-plus fs20']")
    WebElementFacade addCompanySign;

    public void addNewCompany(){
        addCompanySign.click();
    }

    public void waitForElement() {
        addCompanySign.waitUntilVisible();
    }

    public void selectCompany(){

    }
}
