package com.vRoll.autom.pages;

import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.core.steps.ScenarioActor;
import org.openqa.selenium.interactions.Action;
import org.seleniumhq.jetty9.server.HttpChannelState;

public class PayrollUser extends ScenarioActor {


}
