package com.vRoll.autom.actions.navigate;

public class DoubleClickOnElement {

}
