package com.blazedemo.pages;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("http://vgroll.com:8080/vroll/")
public class LoginPage extends PageObject {
}
